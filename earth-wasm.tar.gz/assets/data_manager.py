"""本機存檔及小測彙總。"""
import csv
import json
from pathlib import Path
import re
import sys
from urllib.parse import quote

IN_BROWSER = sys.platform == "emscripten"
if IN_BROWSER:
    from platform import window

STORAGE_KEY = "earth-pygame-v1"
DATA = Path("/tmp/save-mother-earth") if IN_BROWSER else Path.home() / "SaveMotherEarth"
PROJECT = Path(__file__).resolve().parent
ATTEMPT_FIELDS = ("student_id", "attempt_number", "score")


class Data:
    def __init__(self, folder=DATA):
        self.folder = Path(folder)
        self.folder.mkdir(parents=True, exist_ok=True)
        self.save_path = self.folder / "save.json"
        self.quiz_path = self.folder / "quiz_results.csv"
        self.history_path = self.folder / "quiz_attempts.csv"
        self.files = (self.save_path, self.quiz_path, self.history_path)
        if IN_BROWSER:
            try:
                snapshot = json.loads(window.localStorage.getItem(STORAGE_KEY) or "{}")
                for path in self.files:
                    if isinstance(snapshot.get(path.name), str):
                        path.write_text(snapshot[path.name], encoding="utf-8")
                    else:
                        path.unlink(missing_ok=True)
            except (ValueError, TypeError, OSError):
                pass
        self.state = {"demo_pin": "", "student_id": "", "unlocked_level": 0, "best_scores": {},
                      "settings": {"muted": False, "teacher_slow": False}}
        if self.save_path.exists():
            try:
                stored = json.loads(self.save_path.read_text(encoding="utf-8"))
                for key in self.state:
                    if key in stored and isinstance(stored[key], type(self.state[key])):
                        self.state[key] = stored[key]
                self.state["unlocked_level"] = max(0, min(4, self.state["unlocked_level"]))
            except (ValueError, OSError):
                pass

    def save(self):
        temp = self.save_path.with_suffix(".tmp")
        temp.write_text(json.dumps(self.state, ensure_ascii=False, indent=2), encoding="utf-8")
        temp.replace(self.save_path)
        if IN_BROWSER:
            snapshot = {p.name: p.read_text(encoding="utf-8") for p in self.files if p.exists()}
            window.localStorage.setItem(STORAGE_KEY, json.dumps(snapshot, ensure_ascii=False))

    def read_rows(self, path):
        if not path.exists():
            return []
        with path.open(newline="", encoding="utf-8-sig") as file:
            return list(csv.DictReader(file))

    def rows(self):
        summaries = {row["student_id"]: row for row in self.read_rows(self.quiz_path)}
        for attempt in self.read_rows(self.history_path):
            student = attempt["student_id"]
            row = summaries.setdefault(student, dict(student_id=student, attempts=0, best_score=0))
            row["attempts"] = max(int(row["attempts"]), int(attempt["attempt_number"]))
            row["best_score"] = max(int(row["best_score"]), int(attempt["score"]))
        return list(summaries.values())

    def write_attempts(self, path, rows):
        temp = path.with_suffix(".tmp")
        with temp.open("w", newline="", encoding="utf-8-sig") as file:
            writer = csv.DictWriter(file, fieldnames=ATTEMPT_FIELDS)
            writer.writeheader()
            writer.writerows(rows)
        temp.replace(path)

    def record(self, student_id, score):
        if not re.fullmatch(r"[A-Za-z0-9_-]{1,20}", student_id):
            raise ValueError("學號格式錯誤")
        previous_count = next((int(row["attempts"]) for row in self.rows()
                               if row["student_id"] == student_id), 0)
        history = self.read_rows(self.history_path)
        history.append(dict(student_id=student_id, attempt_number=previous_count + 1, score=score))
        self.write_attempts(self.history_path, history)
        self.state["student_id"] = student_id
        self.save()

    def export(self, folder=PROJECT):
        path = Path(folder) / "quiz_export.csv"
        scores = {(row["student_id"], int(row["attempt_number"])): row["score"]
                  for row in self.read_rows(self.history_path)}
        rows = []
        for summary in sorted(self.rows(), key=lambda row: row["student_id"]):
            student = summary["student_id"]
            for number in range(1, int(summary["attempts"]) + 1):
                rows.append(dict(student_id=student, attempt_number=number,
                                 score=scores.get((student, number), "")))
        self.write_attempts(path, rows)
        if IN_BROWSER:
            link = window.document.createElement("a")
            link.href = "data:text/csv;charset=utf-8," + quote(path.read_text(encoding="utf-8"))
            link.download = "quiz_export.csv"
            window.document.body.appendChild(link)
            link.click()
            link.remove()
        return path

    def reset_quiz(self, folder=PROJECT):
        export_path = Path(folder) / "quiz_export.csv"
        # 先清空既有匯出。若 Excel 正在鎖定它，先保留小測紀錄。
        if export_path.exists():
            self.write_attempts(export_path, [])
        self.quiz_path.unlink(missing_ok=True)
        self.history_path.unlink(missing_ok=True)
        self.state["student_id"] = ""
        self.save()
