"""最終版遊戲入口。"""
import asyncio
import sys
from pathlib import Path
from math import pi, sin
from random import shuffle
import os
import re
import pygame
from data_manager import Data, IN_BROWSER
from recycling_guide import answer, CLUES
from python_lessons import LESSONS, run_tests
from game_levels import BINS, ITEMS, LEVELS, TESTS, WIDTH, HEIGHT, WHITE, INK
from ui_components import PictureGame, CREAM, PALE

LEVELS[2][1].extend(["用過的紙巾", "鋁罐", "飲品膠樽", "報紙"])
QUESTIONS = [
    ("乾淨紙箱", "這個乾淨紙箱應該放哪個桶？", "paper", "紙箱是用紙做的，放藍色廢紙桶。"),
    ("飲品膠樽", "這個空膠樽應該放哪個桶？", "plastic", "膠樽是塑料，放黃色膠樽桶。"),
    ("鋁罐", "喝完汽水後，這個空鋁罐要放哪個桶？", "metal", "用材料來判斷：鋁是金屬，所以放棕色桶。"),
    ("用過的紙巾", "這張用過的紙巾應該放哪個桶？", "general", "這張紙巾用過了，本課把它放綠色一般垃圾桶。"),
    ("飲品膠樽", "除錯：如果是膠樽，應把「放入廢紙」換成甚麼？", "plastic", "保留「如果是膠樽」，把動作改為放入黃桶。"),
]
RULES = {
    "paper": "看看它的材料：這是乾淨的紙嗎？",
    "plastic": "想想膠樽的材料：它是紙做的，還是膠做的？",
    "metal": "想一想：鋁是紙、膠，還是金屬？",
    "general": "留意：這張紙巾已經用過，可以當乾淨廢紙嗎？",
}


LEVEL_ONE_TIPS = {
    "報紙": "報紙是印在紙上的。它和膠樽是同一種材料嗎？",
    "乾淨紙箱": "看看紙箱的箱身：它是用厚紙板，還是用塑料做的？",
    "乾淨書本": "翻開書想一想：書頁是用紙，還是用塑料做的？",
    "飲品膠樽": "想想喝完的膠樽：樽身是用紙，還是用塑料做的？",
    "洗頭水樽": "想想洗頭水樽的樽身：它像紙箱，還是像飲品膠樽？",
}


def shuffled_order(items, previous=None):
    order = list(items)
    shuffle(order)
    if order == previous:
        # 重玩時避免整套順序恰好和上一輪一樣。
        for index in range(1, len(order)):
            if order[index] != order[0]:
                order[0], order[index] = order[index], order[0]
                break
    return order


class FinalGame(PictureGame):
    def __init__(self, folder=None):
        super().__init__()
        self.window = pygame.display.set_mode((1280, 720))
        self.screen = pygame.Surface((WIDTH, HEIGHT))
        self.viewport = pygame.Rect(94, 0, 1091, 720)
        self.data = Data() if folder is None else Data(folder)
        self.unlocked = self.data.state["unlocked_level"]
        self.muted = self.data.state["settings"].get("muted", False)
        self.slow = self.data.state["settings"].get("teacher_slow", False)
        self.practice = False
        self.paused = False
        self.teacher_confirm = False
        self.teacher_pin = ""
        self.notice = ""
        self.portrait = pygame.image.load(str(Path(__file__).parent / "assets" / "mother_earth.jpg")).convert()
        self.portraits = {}
        self.pause_rect = pygame.Rect(146, 25, 92, 44)
        self.gear = pygame.Rect(852, 584, 119, 50)
        self.quiz_entry = pygame.Rect(388, 506, 224, 50)
        self.options_extra = ["paper", "plastic", "metal", "general", "skip", "score"]
        self.previous_orders = {}
        self.quiz_buttons = {}
        self.student_id = self.data.state["student_id"]
        self.report_page = 0
        self.ask_open = False
        self.ask_input = False
        self.question = ""
        self.composition = ""
        self.ask_answer = None
        self.ask_submitted = False
        self.ask_unknown = False
        self.ask_examples = ("信封","餅乾罐","玻璃樽")
        self.ask_surface = pygame.Surface((431,720))
        self.ask_button = pygame.Rect(853, 400, 128, 69)
        self.last_wrong = None
        self.tip_elapsed = 0.0

    def toggle_ask(self, opened):
        self.ask_open = opened
        if opened:
            self.viewport = pygame.Rect(0, 80, 847, 559)
            self.ask_input = True
            self.composition = ""
            pygame.key.start_text_input()
            pygame.key.set_text_input_rect(pygame.Rect(864,220,380,50))
        else:
            self.viewport = pygame.Rect(94, 0, 1091, 720)
            self.ask_input = False
            self.composition = ""
            pygame.key.stop_text_input()

    def submit_question(self):
        if self.question.strip() and not self.composition:
            self.ask_answer = answer(self.question)
            self.ask_unknown = self.ask_answer is None
            self.ask_submitted = True

    def ask_event(self,event):
        if event.type == pygame.TEXTINPUT and self.ask_input:
            self.question = (self.question + event.text)[:25]
            self.composition = ""
        elif event.type == pygame.TEXTEDITING:
            self.composition = event.text
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:
                self.toggle_ask(False)
            elif event.key == pygame.K_RETURN:
                self.submit_question()
            elif event.key == pygame.K_BACKSPACE and not self.composition:
                self.question = self.question[:-1]
        elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            x,y = event.pos
            if pygame.Rect(1153,22,104,45).collidepoint(x,y):
                self.toggle_ask(False)
            elif pygame.Rect(1149,222,102,48).collidepoint(x,y):
                self.submit_question()
            elif pygame.Rect(865,222,276,48).collidepoint(x,y):
                self.ask_input = True
            else:
                for idx,example in enumerate(self.ask_examples):
                    if pygame.Rect(866+idx*127,327,119,42).collidepoint(x,y):
                        self.question = example
                        self.composition = ""
                        self.submit_question()
                        return
                if self.ask_unknown:
                    for idx,material in enumerate(CLUES):
                        if pygame.Rect(865+idx*96,568,91,42).collidepoint(x,y):
                            self.ask_answer = CLUES[material]
                            self.ask_unknown = False
                            break

    def draw_ask(self):
        original = self.screen
        self.screen = self.ask_surface
        self.screen.fill("#eaf6eb")
        bob = round(3*sin(pygame.time.get_ticks()/420))
        self.earth((70,86+bob),46)
        self.text("問地球媽媽",131,66,26)
        self.text("垃圾分類小幫手",131,103,19)
        self.button(pygame.Rect(304,22,104,45),"關閉")
        self.text("輸入物品名稱，例如「信封」。",18,180,22)
        self.rect((16,222,276,48),WHITE)
        self.rect((16,222,276,48),"#84b8a6",width=2)
        query = self.question + self.composition
        while query and self.fonts[19].size(query)[0] > 245:
            query = query[1:]
        self.text(query or "在這裏輸入物品",29,234,19)
        self.button(pygame.Rect(300,222,102,48),"提問")
        self.text("也可以點一個例子：",18,291,19)
        for idx,name in enumerate(self.ask_examples):
            self.button(pygame.Rect(17+idx*127,327,119,42),name)
        self.rect((16,401,386,146),CREAM)
        if self.ask_answer:
            title, body = self.ask_answer
            self.text(title,31,417,22)
            self.draw_wrapped(body,31,455)
        elif self.ask_submitted:
            self.text("我還不能確定。",31,417,22)
            self.draw_wrapped("先看看這件物品的材料。它是用甚麼做的？",31,455)
        else:
            self.text("今天想問哪件物品？",31,424,22)
            self.draw_wrapped("告訴我它的名字，我們一起想想。",31,462)
        if self.ask_unknown:
            for idx,material in enumerate(CLUES):
                self.button(pygame.Rect(16+idx*96,568,91,42),material)
        self.text("離線查詢｜實際回收請看回收點指引",18,665,19)
        self.screen = original
        self.window.blit(self.ask_surface,(849,0))
        pygame.display.flip()

    def draw_wrapped(self, body, x, y):
        line = ""
        for char in body:
            if self.fonts[19].size(line+char)[0] > 344:
                self.text(line,x,y,19)
                y += 28
                line = ""
            line += char
        if line:
            self.text(line,x,y,19)

    def menu_rect(self, number):
        return pygame.Rect(84 + number % 3 * 280, 275 + number // 3 * 103, 272, 84)

    def earth(self, center, radius, happy=True):
        if radius not in self.portraits:
            size = radius * 2
            image = pygame.transform.smoothscale(self.portrait, (size, size))
            # 圓形遮罩保留使用者提供的角色原圖。
            result = pygame.Surface((size, size), pygame.SRCALPHA)
            result.blit(image, (0, 0))
            mask = pygame.Surface((size, size), pygame.SRCALPHA)
            pygame.draw.circle(mask, WHITE, (radius, radius), radius)
            result.blit(mask, (0, 0), special_flags=pygame.BLEND_RGBA_MULT)
            self.portraits[radius] = result
        pygame.draw.circle(self.screen, "#53967b" if happy else "#d29258", center, radius+4)
        self.screen.blit(self.portraits[radius], (center[0]-radius,center[1]-radius))
        if not happy:
            self.icon("cross",(center[0]+radius-3,center[1]+radius-3),22)

    def start(self, level, practice=None):
        if practice is not None:
            self.practice = practice
        super().start(3 if level == 4 else level)
        self.level = level
        self.ask_button.y = 166 if level >= 3 else 400
        if level in (1, 2, 3, 4):
            items = self.sequence if level < 3 else TESTS
            order = shuffled_order(items, self.previous_orders.get(level))
            self.previous_orders[level] = order
            if level < 3:
                self.sequence = order
            else:
                self.debug_tests = order
        self.paused = False
        self.last_wrong = None
        self.elapsed = 0
        if level in (3, 4):
            kinds = {"paper": "compare", "metal": "branch", "plastic": "score"}
            self.code_tasks = ["return"] if level == 3 else [kinds[ITEMS[name]] for name in self.debug_tests]
            self.code_index = 0
            self.setup_code_task()

    def finish(self, won):
        self.outcome = "win" if won else "retry"
        self.dragging = False
        if won:
            self.play("win")
            if not self.practice:
                self.unlocked = min(4,max(self.unlocked,self.level+1))
                state = self.data.state
                state["unlocked_level"] = self.unlocked
                key = str(self.level)
                state["best_scores"][key] = max(self.score,state["best_scores"].get(key,0))
                self.data.save()

    def advance_item(self):
        self.last_wrong = None
        super().advance_item()

    def drop_item(self):
        target = next((key for key, area in self.bins.items() if area.collidepoint(self.item.center)),None)
        name = self.sequence[self.item_index]
        self.last_wrong = ITEMS[name] if target is not None and target != ITEMS[name] else None
        super().drop_item()
        if self.last_wrong:
            self.tip_elapsed = 0.0
        if self.last_wrong and not self.outcome:
            self.message = "差一點！看看地球媽媽的提示，再選一次。"

    def update(self, seconds):
        if self.ask_open or self.view == "play" and self.paused:
            return
        if self.view == "play" and self.last_wrong:
            self.tip_elapsed += seconds
        if self.view == "play" and not self.outcome:
            self.elapsed += seconds
        if self.view != "play" or self.level != 4:
            super().update(seconds * (0.55 if self.practice and self.slow else 1))
        if self.view == "play" and self.level == 0 and self.outcome == "win" and not self.practice:
            self.win_delay = getattr(self,"win_delay",0) + seconds
            if self.win_delay >= 4:
                self.win_delay = 0
                self.start(1)
        else:
            self.win_delay = 0

    def handle(self, event):
        if self.ask_open and event.type != pygame.QUIT:
            self.ask_event(event)
            return
        if (self.view == "play" and event.type == pygame.MOUSEBUTTONDOWN
                and event.button == 1 and not self.dragging):
            x,y = event.pos
            pos = ((x-self.viewport.x)*WIDTH//self.viewport.w,
                   (y-self.viewport.y)*HEIGHT//self.viewport.h)
            if self.ask_button.collidepoint(pos):
                self.toggle_ask(True)
                return
        old_muted = self.muted
        if hasattr(event,"pos"):
            x,y = event.pos
            event = pygame.event.Event(event.type, {**event.dict,
                     "pos": ((x-self.viewport.x)*WIDTH//self.viewport.w, (y-self.viewport.y)*HEIGHT//self.viewport.h)})
        self.dispatch(event)
        if self.muted != old_muted:
            self.data.state["settings"]["muted"] = self.muted
            self.data.save()

    def dispatch(self,event):
        if event.type == pygame.KEYDOWN:
            if (self.view == "play" and self.level in (3, 4) and not self.outcome
                    and not self.paused and event.key != pygame.K_ESCAPE):
                self.edit_python(event)
                return
            if event.key == pygame.K_p and self.view == "play" and not self.outcome:
                self.paused = not self.paused
                self.dragging = False
                self.block = None
                if self.level < 3:
                    self.item.topleft = (int(self.item_x),283)
                return
            if self.view == "teacher_login":
                if event.key == pygame.K_ESCAPE:
                    self.view = "menu"
                    self.teacher_pin = self.notice = ""
                elif event.key in (pygame.K_RETURN, pygame.K_KP_ENTER):
                    self.submit_teacher_pin()
                elif event.key == pygame.K_BACKSPACE:
                    self.teacher_pin = self.teacher_pin[:-1]
                    self.notice = ""
                elif len(self.teacher_pin) < 5 and re.fullmatch(r"[0-9]", event.unicode):
                    self.teacher_pin += event.unicode
                    self.notice = ""
                return
            if self.view == "quiz_id":
                if event.key == pygame.K_BACKSPACE:
                    self.student_id = self.student_id[:-1]
                elif event.key == pygame.K_RETURN:
                    self.begin_quiz()
                elif len(self.student_id)<20 and re.fullmatch(r"[A-Za-z0-9_-]",event.unicode):
                    self.student_id += event.unicode
                if event.key != pygame.K_ESCAPE:
                    return

        if self.view == "play" and self.paused and event.type in (
            pygame.MOUSEBUTTONDOWN,pygame.MOUSEBUTTONUP,pygame.MOUSEMOTION
        ):
            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                if self.pause_rect.collidepoint(event.pos):
                    self.paused = False
                elif self.back.collidepoint(event.pos):
                    self.view = "teacher" if self.practice else "menu"
                elif self.mute.collidepoint(event.pos):
                    self.muted = not self.muted
            return

        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            pos = event.pos
            if self.view == "menu":
                self.practice = False
                for level in range(self.unlocked + 1):
                    if self.menu_rect(level).collidepoint(pos):
                        self.start(level)
                        return
                if self.quiz_entry.collidepoint(pos):
                    self.view = "quiz_id"
                    self.notice = ""
                    return
                if self.gear.collidepoint(pos):
                    self.teacher_pin = self.notice = ""
                    self.view = "teacher_login"
                    return
            if self.view == "play":
                if self.pause_rect.collidepoint(pos) and not self.outcome:
                    self.paused = True
                    self.dragging = False
                    self.block = None
                    if self.level < 3:
                        self.item.topleft = (int(self.item_x),283)
                    return
                if self.practice and (self.back.collidepoint(pos) or
                                      self.outcome and self.next.collidepoint(pos)):
                    self.view = "teacher"
                    return
                if self.outcome == "win" and self.level in (3,4) and self.next.collidepoint(pos):
                    if self.level == 3:
                        self.start(4)
                    else:
                        self.view = "reflection"
                        self.reflect_done.clear()
                    return
                if self.level in (3, 4) and not self.outcome:
                    if self.back.collidepoint(pos):
                        self.view = "teacher" if self.practice else "menu"
                    elif self.mute.collidepoint(pos):
                        self.muted = not self.muted
                    else:
                        self.click_python(pos)
                    return
            if self.view in ("teacher_login","teacher","report","quiz_reset","quiz_id","quiz","quiz_result"):
                self.special_click(pos)
                return
        super().handle(event)

    def submit_teacher_pin(self):
        saved_pin = self.data.state.get("demo_pin", "")
        if IN_BROWSER and not saved_pin and len(self.teacher_pin) == 5:
            saved_pin = self.teacher_pin
            self.data.state["demo_pin"] = saved_pin
            self.data.save()
        if saved_pin and self.teacher_pin == saved_pin:
            self.view = "teacher"
            self.notice = ""
        else:
            self.notice = "密碼不正確，請再試一次。"
        self.teacher_pin = ""

    def begin_quiz(self):
        if not re.fullmatch(r"[A-Za-z0-9_-]{1,20}", self.student_id):
            self.notice = "請輸入學號，例如 S001。"
            return
        self.quiz_questions = shuffled_order(QUESTIONS, self.previous_orders.get("quiz"))
        self.previous_orders["quiz"] = self.quiz_questions
        self.shuffle_quiz_bins()
        self.q_index = self.q_score = 0
        self.q_choice = None
        self.view = "quiz"

    def shuffle_quiz_bins(self):
        order = shuffled_order(BINS, list(self.quiz_buttons))
        self.quiz_buttons = {
            category: pygame.Rect(62 + index * 225, 361, 200, 112)
            for index, category in enumerate(order)
        }

    def special_click(self,pos):
        if self.mute.collidepoint(pos):
            self.muted = not self.muted
        elif self.back.collidepoint(pos):
            self.view = {"quiz_reset": "report", "report": "teacher"}.get(self.view, "menu")
            self.notice = ""
            self.teacher_confirm = False
        elif self.view == "teacher_login" and self.go.collidepoint(pos):
            self.submit_teacher_pin()
        elif self.view == "teacher":
            for level in range(5):
                if self.menu_rect(level).collidepoint(pos):
                    self.start(level,practice=True)
                    return
            if pygame.Rect(84,503,232,52).collidepoint(pos):
                self.slow = not self.slow
                self.data.state["settings"]["teacher_slow"] = self.slow
                self.data.save()
            elif pygame.Rect(383,503,232,52).collidepoint(pos):
                self.view = "report"
                self.report_page = 0
                self.notice = ""
            elif pygame.Rect(682,503,232,52).collidepoint(pos):
                if self.teacher_confirm:
                    self.unlocked = 0
                    self.data.state["unlocked_level"] = 0
                    self.data.state["best_scores"] = {}
                    self.data.save()
                    self.teacher_confirm = False
                    self.notice = "關卡進度已重置。小測成績仍保留。"
                else:
                    self.teacher_confirm = True
                    self.notice = "再按一次「重置關卡」確認。"
        elif self.view == "quiz_reset":
            if self.go.collidepoint(pos):
                try:
                    self.data.reset_quiz()
                except OSError:
                    self.notice = "初始化失敗。請關閉 Excel 中的 CSV，再試一次。"
                    return
                self.student_id = ""
                self.report_page = 0
                self.view = "report"
                self.notice = "小測已初始化。下一次作答會從第 1 次開始。"
        elif self.view == "report":
            rows = self.data.rows()
            if pygame.Rect(88,546,146,50).collidepoint(pos):
                self.report_page = max(0,self.report_page-1)
            elif pygame.Rect(249,546,146,50).collidepoint(pos):
                self.report_page = min(max(0,(len(rows)-1)//8),self.report_page+1)
            elif pygame.Rect(422,546,215,50).collidepoint(pos):
                self.view = "quiz_reset"
                self.notice = ""
            elif pygame.Rect(664,546,248,50).collidepoint(pos):
                try:
                    self.data.export()
                    self.notice = "已開始下載：quiz_export.csv"
                except OSError:
                    self.notice = "匯出失敗。請關閉 Excel 中的 CSV，再試一次。"
        elif self.view == "quiz_id" and self.go.collidepoint(pos):
            self.begin_quiz()
        elif self.view == "quiz":
            if self.q_choice is not None:
                if self.go.collidepoint(pos):
                    self.q_index += 1
                    self.q_choice = None
                    if self.q_index == len(self.quiz_questions):
                        self.data.record(self.student_id,self.q_score)
                        self.view = "quiz_result"
                    else:
                        self.shuffle_quiz_bins()
            else:
                for key,area in self.quiz_buttons.items():
                    if area.collidepoint(pos):
                        self.q_choice = key
                        right = key == self.quiz_questions[self.q_index][2]
                        self.q_score += 20 if right else 0
                        self.play("right" if right else "wrong")
                        break
        elif self.view == "quiz_result" and self.go.collidepoint(pos):
            self.view = "menu"

    def draw_menu(self):
        self.earth((500,113),80)
        self.text("地球媽媽拯救大作戰",500,213,44,center=True)
        self.text("香港小四至小五｜垃圾分類與計算思維",500,250,19,center=True)
        self.draw_level_cards(False)
        self.button(self.quiz_entry,"課後小測")
        self.button(self.gear,"教師模式")
        self.text("選一關開始。放錯桶時，地球媽媽會給你一個提示。",500,597,22,center=True)

    def draw_level_cards(self,teacher):
        names = ("膠樽入門","分類練習","四桶挑戰","Python 除錯","Python 挑戰")
        for level,key in enumerate(("plastic","paper","metal","bulb","robot")):
            area = self.menu_rect(level)
            locked = not teacher and level>self.unlocked
            self.rect(area.move(0,4),"#bfd9c9")
            self.rect(area,"#f0f3eb" if locked else WHITE)
            self.icon(key,(area.x+43,area.centery),52)
            self.text(f"{level}　{names[level]}",area.x+82,area.y+13,22)
            best = self.data.state["best_scores"].get(str(level))
            sub = "未解鎖" if locked else "試玩" if teacher else f"最高 {best} 分" if best is not None else "開始"
            self.text(sub,area.x+84,area.y+47,19)

    def draw_header(self):
        super().draw_header()
        if self.level == 4:
            # 基礎畫面只識別 0 至 3；最終關由 draw_play 繪製標題。
            return
        self.draw_controls()

    def draw_controls(self):
        if self.level in (0,3):
            self.rect((112,96,193,55),WHITE,0)
            self.text("跟我試一試" if self.level==0 else "慢慢試",125,110,22)
        if not self.outcome:
            self.button(self.pause_rect,"繼續" if self.paused else "暫停")
        if self.practice:
            self.text("教師練習",264,37,19)

    def setup_code_task(self):
        self.code_kind = self.code_tasks[self.code_index]
        self.code_line = LESSONS[self.code_kind][2]
        self.code_caret = len(self.code_line)
        self.code_results = None
        self.code_error = ""
        self.code_passed = False
        self.code_run = pygame.Rect(737, 424, 168, 46)
        self.code_reset = pygame.Rect(92, 424, 155, 46)
        self.code_edit = pygame.Rect(92, 340, 813, 49)

    def test_python(self):
        order = [ITEMS[name] for name in self.debug_tests] if self.level == 3 else None
        self.code_results, self.code_error = run_tests(self.code_kind, self.code_line, order)
        self.code_passed = self.code_results is not None and all(
            actual == expected for _, actual, expected in self.code_results)
        self.feedback(self.code_passed)

    def edit_python(self, event):
        if event.key in (pygame.K_RETURN, pygame.K_KP_ENTER):
            if self.code_passed:
                self.advance_python()
            else:
                self.test_python()
            return
        if event.key == pygame.K_LEFT:
            self.code_caret = max(0, self.code_caret - 1)
            return
        if event.key == pygame.K_RIGHT:
            self.code_caret = min(len(self.code_line), self.code_caret + 1)
            return
        if event.key == pygame.K_HOME:
            self.code_caret = 0
            return
        if event.key == pygame.K_END:
            self.code_caret = len(self.code_line)
            return
        left = self.code_line[:self.code_caret]
        right = self.code_line[self.code_caret:]
        if event.key == pygame.K_BACKSPACE:
            left = left[:-1]
        elif event.key == pygame.K_DELETE:
            right = right[1:]
        elif len(self.code_line) < 40 and event.unicode and event.unicode.isascii() and event.unicode.isprintable():
            left += event.unicode
        else:
            return
        self.code_line = left + right
        self.code_caret = len(left)
        self.code_results = None
        self.code_error = ""
        self.code_passed = False

    def advance_python(self):
        self.score += 30 if self.level == 3 else 10
        self.code_index += 1
        if self.code_index == len(self.code_tasks):
            self.finish(True)
        else:
            self.setup_code_task()

    def click_python(self, pos):
        if self.code_run.collidepoint(pos):
            if self.code_passed:
                self.advance_python()
            else:
                self.test_python()
        elif self.code_reset.collidepoint(pos):
            self.setup_code_task()
        elif self.code_edit.collidepoint(pos):
            x = pos[0] - 110
            self.code_caret = min(range(len(self.code_line) + 1),
                                  key=lambda i: abs(self.fonts[22].size(self.code_line[:i])[0] - x))

    def draw_debug_card(self):
        if self.outcome:
            return
        title, prefix, _, hint = LESSONS[self.code_kind]
        self.text(f"{title}   ·   {self.code_index+1}／{len(self.code_tasks)}",500,196,26,center=True)
        self.text(hint,500,230,19,center=True)
        self.rect((92,257,813,164),WHITE)
        for index,line in enumerate(prefix):
            self.text(line,110,269+36*index,22)
        self.rect(self.code_edit,CREAM)
        self.text(self.code_line,110,350,22)
        if self.code_kind == "return":
            self.text("    return item",110,394,19)
        if pygame.time.get_ticks() // 450 % 2 == 0:
            cursor = 110 + self.fonts[22].size(self.code_line[:self.code_caret])[0]
            pygame.draw.line(self.screen,INK,(cursor,349),(cursor,376),2)
        self.button(self.code_reset,"還原原始碼")
        self.button(self.code_run,"繼續" if self.code_passed else "執行測試")
        self.text("修改米色那一行，再按 Enter。",500,444,19,center=True)
        if self.code_error:
            self.text(self.code_error,500,521,22,center=True)
        elif self.code_results is not None:
            for index,(value,actual,expected) in enumerate(self.code_results):
                y = 502 + index*37
                self.icon("check" if actual==expected else "cross",(101,y+12),25)
                self.text(f"{value!r}  →  {actual!r}     預期 {expected!r}",132,y,19)
            if self.code_passed:
                self.text("測試全部通過！",775,521,22,center=True)

    def draw_ai_tip(self, y):
        # 直接使用地球媽媽原圖，讓頭像短暫入場並輕輕點頭。
        self.rect((195,y+4,654,68),"#b9d6c7",15)
        self.rect((195,y,654,68),CREAM,15)
        pygame.draw.polygon(self.screen,CREAM,[(196,y+23),(178,y+34),(196,y+44)])
        self.text("地球媽媽 · 分類提示",221,y+7,19)

        progress = min(self.tip_elapsed / 0.24, 1.0)
        slide = round(17 * (1 - progress) ** 2)
        nod = sin(pi * min(max((self.tip_elapsed - 0.20) / 0.46, 0), 1))
        x, cy = 146-slide, y+34+round(nod*4)
        self.earth((x,cy),35)
        portrait = pygame.transform.rotate(self.portraits[35], -9*nod)
        # 覆蓋原來的靜止頭像，使角色的點頭動作清楚可見。
        pygame.draw.circle(self.screen,"#53967b",(x,cy),39)
        self.screen.blit(portrait,portrait.get_rect(center=(x,cy)))
        if self.tip_elapsed < 0.72:
            glow = max(0.0, sin(pi*self.tip_elapsed/0.72))
            for sx,sy in ((x-43,cy-20),(x+29,cy-38)):
                r=round(5*glow)
                if r:
                    pygame.draw.polygon(self.screen,"#e5b344",[(sx-r,sy),(sx,sy-r),(sx+r,sy),(sx,sy+r)])

        tip = RULES[self.last_wrong]
        if self.level == 1:
            name = self.sequence[self.item_index]
            tip = LEVEL_ONE_TIPS.get(name, tip)
        self.text(tip,221,y+34,22)

    def logical_mouse(self):
        x,y = pygame.mouse.get_pos()
        return (x-self.viewport.x)*WIDTH//self.viewport.w,y*HEIGHT//self.viewport.h

    def draw_special(self):
        self.button(self.back,"返回")
        titles = {"quiz_reset":"初始化小測","teacher_login":"教師登入","teacher":"教師模式","report":"小測報告","quiz_id":"課後小測",
                  "quiz":"課後小測","quiz_result":"你完成了小測！"}
        self.text(titles[self.view],500,84,44,center=True)
        if self.view == "teacher_login":
            self.earth((500,222),64)
            self.text("請輸入教師密碼" if self.data.state.get("demo_pin") else "首次使用：設定 5 位數演示 PIN",500,326,26,center=True)
            self.rect((324,375,352,68),WHITE)
            self.text("● " * len(self.teacher_pin) or "輸入 5 位數字",500,409,22,center=True)
            self.text(self.notice,500,488,22,center=True)
            self.button(self.go,"登入")
        elif self.view == "teacher":
            self.text("任選一關試玩，練習結果不會計入學生進度。",500,170,22,center=True)
            self.draw_level_cards(True)
            for x,label in ((84,"慢速：開" if self.slow else "慢速：關"),(383,"查看小測報告"),(682,"重置關卡")):
                self.button(pygame.Rect(x,503,232,52),label)
            self.text(self.notice,500,598,22,center=True)
        elif self.view == "quiz_reset":
            self.text("這會清除這台電腦的學生小測紀錄。",500,245,26,center=True)
            self.text("之後下載的 CSV 將只包含新紀錄。",500,296,22,center=True)
            self.text("要保留舊成績，請先把匯出的 CSV 移到別的資料夾。",500,354,22,center=True)
            self.text(self.notice,500,470,22,center=True)
            self.button(self.go,"確認清除")
        elif self.view == "report":
            self.text("學號　　　　　　　　作答次數　　　　　　　　最高分",500,154,22,center=True)
            rows = self.data.rows()
            for i,row in enumerate(rows[self.report_page*8:self.report_page*8+8]):
                y = 189+i*41
                self.rect((123,y,754,36),WHITE,6)
                for x,key in ((233,"student_id"),(500,"attempts"),(757,"best_score")):
                    self.text(str(row[key]),x,y+18,19,center=True)
            if not rows:
                self.text("還沒有小測成績。",500,265,22,center=True)
            for x,w,label in ((88,146,"上一頁"),(249,146,"下一頁"),(422,215,"初始化小測"),(664,248,"匯出 CSV")):
                self.button(pygame.Rect(x,546,w,50),label)
            self.text(self.notice or "每次作答各佔一行，CSV 由瀏覽器下載。",500,621,19,center=True)
        elif self.view == "quiz_id":
            self.earth((500,218),70)
            self.text("輸入學號，然後開始。",500,338,26,center=True)
            self.rect((310,389,380,61),WHITE)
            self.text(self.student_id+"│",500,420,26,center=True)
            self.text(self.notice or "共 5 題，每題 20 分。",500,490,22,center=True)
            self.button(self.go,"開始小測")
        elif self.view == "quiz":
            name, question, expected, explanation = self.quiz_questions[self.q_index]
            self.text(f"{self.q_index+1}／5",500,135,22,center=True)
            self.text(question,500,187,26,center=True)
            self.item_icon(name,(500,270),105)
            for key,area in self.quiz_buttons.items():
                self.bin_art(key,area)
                if self.q_choice is not None and (key==expected or key==self.q_choice):
                    self.icon("check" if key==expected else "cross",(area.right-15,area.y+14),32)
            if self.q_choice is not None:
                self.text(explanation,500,518,22,center=True)
                self.button(self.go,"看結果" if self.q_index==4 else "下一題")
        else:
            self.earth((500,252),100)
            self.text(f"{self.q_score}／100",500,409,44,center=True)
            self.text("本次結果已記錄。選一關再練習吧！",500,491,22,center=True)
            self.button(self.go,"返回選關")

    def draw_play(self):
        if self.level in (3, 4):
            level = self.level
            # 沿用關卡狀態列，下方留給單題卡片。
            message = self.message
            self.level = 3
            self.message = ""
            PictureGame.draw_header(self)
            self.level = level
            self.message = message
            self.rect((241,23,490,49),"#e7f4e7",0)
            title = "Python 除錯" if level == 3 else "Python 挑戰"
            self.text(f"第 {level} 關　{title}",500,45,32,center=True)
            self.draw_controls()
            self.draw_debug_card()
        else:
            self.draw_header()
            self.draw_sort()
        if self.last_wrong and not self.outcome:
            self.draw_ai_tip(397)
        if self.outcome:
            self.draw_result()
            if self.outcome=="retry":
                self.rect((230,227,540,64),WHITE)
                self.text("地球媽媽難過了，再試一次",500,257,32,center=True)
            elif self.level in (3,4):
                self.rect((230,227,540,64),WHITE)
                self.text("第一處錯誤已修好！" if self.level==3 else "地球媽媽得救了！",500,257,32,center=True)
                if self.level==4:
                    self.earth((500,186),46)
                    for i in range(8):
                        t = pygame.time.get_ticks()//24 + i*21
                        pygame.draw.circle(self.screen,("#dd985a","#6dbb9a","#8d76c2")[i%3],
                                           (301+i*57,148+(t%88)),4)
                self.button(self.next,"返回教師模式" if self.practice else "下一關" if self.level==3 else "開始反思")
            if self.practice:
                self.button(self.next,"返回教師模式")
            if self.outcome == "retry" and self.last_wrong:
                self.draw_ai_tip(478)
        if self.paused:
            self.rect((260,270,480,128),WHITE)
            self.text("暫停中",500,309,32,center=True)
            self.text("按 P 或點「繼續」回到遊戲。",500,360,22,center=True)

    def draw(self):
        self.screen.fill("#e7f4e7")
        pygame.draw.ellipse(self.screen,"#d4ead9",(-260,555,1150,220))
        pygame.draw.ellipse(self.screen,"#d0e9d9",(540,560,800,190))
        if self.view == "menu":
            self.draw_menu()
        elif self.view == "reflection":
            self.draw_reflection()
        elif self.view == "play":
            self.draw_play()
        else:
            self.draw_special()
        if self.view == "play":
            self.rect(self.ask_button,WHITE,13)
            self.rect(self.ask_button,"#84b8a6",13,2)
            self.earth((917,self.ask_button.y+16),18)
            self.text("問地球媽媽",917,self.ask_button.y+51,19,center=True)
        self.button(self.mute,"開聲" if self.muted else "靜音")
        self.window.fill("#163b3b")
        self.window.blit(pygame.transform.smoothscale(self.screen,self.viewport.size),self.viewport)
        if self.ask_open:
            self.draw_ask()
        else:
            pygame.display.flip()


async def main():
    game = FinalGame()
    while game.running:
        seconds = min(game.clock.tick(0 if IN_BROWSER else 60) / 1000, 0.05)
        for event in pygame.event.get():
            game.handle(event)
        if game.running:
            game.update(seconds)
            game.draw()
        await asyncio.sleep(0)


if __name__ == "__main__":
    asyncio.run(main())
