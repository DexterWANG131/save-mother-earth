"""Python 除錯題。只分析本課支援的語法，不執行學生輸入的程式。"""
import ast

LESSONS = {
    "return": ("1｜改回傳值", ("def classify(item):", '    if item == "plastic":'),
               '        return "paper"', "膠樽屬於 plastic。看看 return 後面的字串。"),
    "compare": ("2｜修正比較符號", ("def is_paper(item):",),
                '    return item = "paper"', "比較兩個值要用兩個等號：==。"),
    "branch": ("3｜修正條件", ("def is_metal(item):",),
               '    return item == "plastic"', "想一想：我們要找的是 metal，還是 plastic？"),
    "score": ("4｜修正加分", ("def add_points(score):",),
              "    return score - 10", "答對時應加 10 分。看看用了加號還是減號。"),
}

# Each test has a fixed input and expected output.
TEST_CASES = {
    "return": (("plastic", "plastic"), ("paper", "paper"), ("metal", "metal")),
    "compare": (("paper", True), ("plastic", False)),
    "branch": (("metal", True), ("paper", False)),
    "score": ((0, 10), (20, 30)),
}


def run_tests(kind, line, order=None):
    prefix = LESSONS[kind][1]
    suffix = ("    return item",) if kind == "return" else ()
    code = "\n".join((*prefix, line, *suffix))
    try:
        body = ast.parse(code).body[0].body
    except SyntaxError:
        return None, "語法未通過。請檢查等號、引號和縮排。"
    if kind == "return":
        if len(body) != 2 or len(body[0].body) != 1:
            return None, "請只修改亮色的 return 那一行。"
        statement = body[0].body[0]
    else:
        if len(body) != 1:
            return None, "請保留一行 return。"
        statement = body[0]
    if not isinstance(statement, ast.Return):
        return None, "請保留 return，讓函數交回結果。"
    expr = statement.value

    def constant(node, expected_type):
        return isinstance(node, ast.Constant) and type(node.value) is expected_type

    if kind == "return" and constant(expr, str):
        evaluate = lambda value: expr.value if value == "plastic" else value
    elif (kind in ("compare", "branch") and isinstance(expr, ast.Compare)
          and isinstance(expr.left, ast.Name) and expr.left.id == "item"
          and len(expr.ops) == 1 and isinstance(expr.ops[0], (ast.Eq, ast.NotEq))
          and constant(expr.comparators[0], str)):
        def evaluate(value):
            equal = value == expr.comparators[0].value
            return equal if isinstance(expr.ops[0], ast.Eq) else not equal
    elif (kind == "score" and isinstance(expr, ast.BinOp)
          and isinstance(expr.left, ast.Name) and expr.left.id == "score"
          and isinstance(expr.op, (ast.Add, ast.Sub)) and constant(expr.right, int)):
        def evaluate(value):
            return value + expr.right.value if isinstance(expr.op, ast.Add) else value - expr.right.value
    else:
        return None, "保留 return，按提示修改這一行。"

    cases = dict(TEST_CASES[kind])
    ordered = order if order is not None else cases
    return [(value, evaluate(value), cases[value]) for value in ordered], ""
