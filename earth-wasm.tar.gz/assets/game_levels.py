"""《地球媽媽拯救大作戰》：按 main.py 啟動。"""
from array import array
from math import pi, sin
from pathlib import Path
import os
import pygame

WIDTH, HEIGHT = 1000, 660
BG = "#eff7ed"
INK = "#193a35"
WHITE = "#ffffff"
GREEN = "#267753"
BINS = {
    "paper": ("廢紙", "紙", "#3265ac"),
    "plastic": ("膠樽／塑料", "膠", "#f7c746"),
    "metal": ("金屬", "金", "#8a5340"),
    "general": ("一般垃圾", "餘", "#34795d"),
}
ITEMS = {
    "飲品膠樽": "plastic", "洗頭水樽": "plastic",
    "報紙": "paper", "乾淨紙箱": "paper", "乾淨書本": "paper",
    "鋁罐": "metal", "罐頭盒": "metal",
    "用過的紙巾": "general",
}
LEVELS = {
    0: ("膠樽入門", ["飲品膠樽"], 35),
    1: ("分類練習", ["報紙", "飲品膠樽", "乾淨紙箱", "洗頭水樽", "乾淨書本"], 90),
    2: ("傳送帶挑戰", ["鋁罐", "報紙", "用過的紙巾", "洗頭水樽",
                      "罐頭盒", "乾淨紙箱", "飲品膠樽", "用過的紙巾",
                      "鋁罐", "乾淨書本", "飲品膠樽", "罐頭盒"], 155),
}
TESTS = ["飲品膠樽", "報紙", "鋁罐"]


def chinese_font(size):
    bundled = Path(__file__).resolve().parent / "assets" / "NotoSansTC.ttf"
    if bundled.is_file():
        return pygame.font.Font(str(bundled), size)
    # macOS 自帶的黑體也能顯示繁體中文字。
    mac_font = Path("/System/Library/Fonts/STHeiti Medium.ttc")
    if mac_font.exists():
        return pygame.font.Font(str(mac_font), size)
    windows_fonts = Path(os.environ.get("WINDIR", "C:/Windows")) / "Fonts"
    for filename in ("msjh.ttc", "msjh.ttf", "msyh.ttc", "mingliu.ttc"):
        path = windows_fonts / filename
        if path.exists():
            return pygame.font.Font(str(path), size)
    for name in ("microsoftjhenghei", "notosanscjktc", "pingfangtc",
                 "microsoftyahei", "simhei", "notosanscjksc"):
        path = pygame.font.match_font(name)
        if path:
            return pygame.font.Font(path, size)
    raise RuntimeError("請先安裝可顯示繁體中文的字體，例如 Noto Sans CJK TC。")


def make_sound(frequencies):
    if not pygame.mixer.get_init():
        return None
    rate, _, channels = pygame.mixer.get_init()
    samples = array("h")
    for frequency in frequencies:
        count = int(rate * 0.11)
        for index in range(count):
            sample = int(4800 * (1 - index / count) * sin(2 * pi * frequency * index / rate))
            samples.extend([sample] * channels)
    return pygame.mixer.Sound(buffer=samples.tobytes())


class Game:
    def __init__(self):
        pygame.mixer.pre_init(44100, -16, 1, 512)
        pygame.init()
        self.screen = pygame.display.set_mode((WIDTH, HEIGHT))
        pygame.display.set_caption("地球媽媽拯救大作戰")
        self.clock = pygame.time.Clock()
        self.fonts = {size: chinese_font(size) for size in (19, 22, 26, 32, 44, 54)}
        self.sounds = {"right": make_sound([660, 880]), "wrong": make_sound([330, 220]),
                       "combo": make_sound([660, 880, 1100]), "win": make_sound([523, 659, 784, 1047])}
        self.unlocked = 0
        self.flash = 0
        self.muted = False
        self.running = True
        self.view = "menu"
        self.level = 0
        self.back = pygame.Rect(28, 24, 112, 45)
        self.mute = pygame.Rect(856, 24, 116, 45)
        self.next = pygame.Rect(510, 384, 218, 54)
        self.retry = pygame.Rect(272, 384, 218, 54)

    def play(self, kind):
        sound = self.sounds[kind]
        if sound and not self.muted:
            sound.play()

    def menu_rect(self, number):
        return pygame.Rect(130 + number % 2 * 380, 266 + number // 2 * 104, 360, 86)

    def start(self, level):
        self.level = level
        self.view = "play"
        self.outcome = None
        self.hp = 3
        self.score = self.combo = self.correct = 0
        self.dragging = False
        self.offset = (0, 0)
        self.flash = 0
        self.emotion = "happy"
        self.item = pygame.Rect(0, 0, 160, 65)
        categories = list(BINS) if level in (2, 3) else ["paper", "plastic"]
        width = 200
        gap = (WIDTH - len(categories) * width) // (len(categories) + 1)
        self.bins = {key: pygame.Rect(gap + i * (width + gap), 486, width, 112)
                     for i, key in enumerate(categories)}
        if level == 3:
            self.rules = {key: key for key in BINS}
            self.rules["plastic"] = "paper"
            self.stage = "repair"
            self.test_index = 0
            self.debug_tests = list(TESTS)
            self.block = None
            self.slot = pygame.Rect(380, 237, 240, 58)
            self.options = {key: pygame.Rect(78 + i * 216, 354, 198, 60)
                            for i, key in enumerate(("paper", "plastic", "metal", "general"))}
            self.message = "觀察錯誤規則，再拖動下方積木替換它。"
        else:
            _, sequence, self.speed = LEVELS[level]
            self.sequence = sequence
            self.item_index = 0
            self.spawn()
            self.message = "試一試：把膠樽拖進黃色的膠樽桶。" if level == 0 else "按住物品，拖到合適的桶，再放開滑鼠。"

    def spawn(self):
        # 教程物品先出現在視線中央，之後沿傳送帶往左移動。
        self.item_x = 600.0 if self.level == 0 else 810.0
        self.item.topleft = (int(self.item_x), 283)

    def finish(self, won):
        self.outcome = "win" if won else "retry"
        self.dragging = False
        if won:
            self.unlocked = max(self.unlocked, min(self.level + 1, 3))
            self.play("win")

    def feedback(self, right):
        self.emotion = "happy" if right else "sad"
        self.flash = 1.05
        self.play("right" if right else "wrong")

    def advance_item(self):
        if self.level == 0 and self.correct >= 1:
            self.finish(True)
        elif self.level == 1 and self.correct >= 5:
            self.finish(True)
        elif self.level == 2 and self.score >= 150 and self.hp > 0:
            self.finish(True)
        else:
            self.item_index += 1
            if self.item_index == len(self.sequence):
                if self.level == 2:
                    self.finish(False)
                    return
                # 基礎關可以繼續練習，直到成功分類五次。
                self.item_index = 0
            self.spawn()

    def drop_item(self):
        # 用物品的中心點判斷它落在哪一個桶。
        target = next((key for key, rect in self.bins.items()
                       if rect.collidepoint(self.item.center)), None)
        if target is None:
            self.item.topleft = (int(self.item_x), 283)
            self.message = "請把物品放進桶內。"
            return

        name = self.sequence[self.item_index]
        if target == ITEMS[name]:
            self.correct += 1
            self.combo += 1
            bonus = 5 if self.level == 2 and self.combo >= 3 else 0
            self.score += 10 + bonus
            self.feedback(True)
            if bonus:
                self.play("combo")
            self.message = "分類正確！" if not bonus else f"連擊 ×{self.combo}！額外加 5 分。"
            self.advance_item()
        else:
            self.combo = 0
            self.feedback(False)
            self.message = f"再想一想：{name}應放進{BINS[ITEMS[name]][0]}桶。"
            if self.level > 0:
                self.hp -= 1
            self.item.topleft = (int(self.item_x), 283)
            if self.hp <= 0:
                self.finish(False)

    def repair(self, key):
        # 積木代表分類程式的輸出。先用膠樽執行一次改過的規則。
        self.rules["plastic"] = key
        if self.rules["plastic"] != "plastic":
            self.feedback(False)
            self.message = f"程式仍把膠樽送到{BINS[key][0]}桶。請再換一塊積木。"
            return
        self.stage = "verify"
        self.feedback(True)
        self.message = "規則已更換。請預測程式會把每件物品送到哪個桶。"

    def verify(self, chosen):
        category = ITEMS[self.debug_tests[self.test_index]]
        # 這裏真的執行分類規則，再把程式結果與正確分類比較。
        actual = self.rules[category]
        if chosen != actual or actual != category:
            self.feedback(False)
            self.message = f"程式輸出是「{BINS[actual][0]}」。再試一次。"
            return
        self.feedback(True)
        self.score += 10
        self.test_index += 1
        if self.test_index == len(self.debug_tests):
            self.finish(True)
        else:
            self.message = "驗證成功！請測試下一件物品。"

    def handle(self, event):
        if event.type == pygame.QUIT:
            self.running = False
            return
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:
                self.view = "menu"
                self.dragging = False
            elif event.key == pygame.K_r and self.view == "play":
                self.start(self.level)
            return

        if event.type == pygame.MOUSEMOTION:
            if self.view == "play" and self.dragging and self.level != 3:
                self.item.topleft = (event.pos[0] - self.offset[0], event.pos[1] - self.offset[1])
            return
        if event.type not in (pygame.MOUSEBUTTONDOWN, pygame.MOUSEBUTTONUP) or event.button != 1:
            return

        pos = event.pos
        if event.type == pygame.MOUSEBUTTONDOWN:
            if self.mute.collidepoint(pos):
                self.muted = not self.muted
            elif self.view == "menu":
                for number in range(self.unlocked + 1):
                    if self.menu_rect(number).collidepoint(pos):
                        self.start(number)
                        break
            elif self.back.collidepoint(pos):
                self.view = "menu"
                self.dragging = False
            elif self.outcome:
                if self.retry.collidepoint(pos):
                    self.start(self.level)
                elif self.next.collidepoint(pos):
                    if self.outcome == "win" and self.level < 3:
                        self.start(self.level + 1)
                    else:
                        self.view = "menu"
            elif self.level != 3 and self.item.collidepoint(pos):
                self.dragging = True
                self.offset = (pos[0] - self.item.x, pos[1] - self.item.y)
            elif self.level == 3 and self.stage == "repair":
                self.block = next((key for key, rect in self.options.items()
                                   if rect.collidepoint(pos)), None)
            elif self.level == 3 and self.stage == "verify":
                for key, rect in self.bins.items():
                    if rect.collidepoint(pos):
                        self.verify(key)
                        break
        elif self.view == "play" and not self.outcome:
            if self.level != 3 and self.dragging:
                self.dragging = False
                self.item.topleft = (pos[0] - self.offset[0], pos[1] - self.offset[1])
                self.drop_item()
            elif self.level == 3 and self.block is not None:
                block = self.block
                self.block = None
                if self.slot.collidepoint(pos):
                    self.repair(block)

    def update(self, seconds):
        self.flash = max(0, self.flash - seconds)
        if self.view != "play" or self.outcome or self.level == 3 or self.dragging:
            return
        self.item_x -= self.speed * seconds
        self.item.x = int(self.item_x)
        if self.item.right < 0:
            self.combo = 0
            if self.level == 2:
                self.hp -= 1
                self.feedback(False)
                self.message = "漏掉了一件物品，生命值減 1。"
                if self.hp == 0:
                    self.finish(False)
                    return
            else:
                self.message = "沒關係，下一件物品來了。"
            self.advance_item()

    def rect(self, rect, color, radius=14, width=0):
        pygame.draw.rect(self.screen, color, rect, width=width, border_radius=radius)

    def text(self, value, x, y, size=22, color=INK, center=False):
        surface = self.fonts[size].render(value, True, color)
        area = surface.get_rect(center=(x, y)) if center else surface.get_rect(topleft=(x, y))
        self.screen.blit(surface, area)

    def button(self, rect, label, active=True):
        self.rect(rect, GREEN if active else "#dce7dc")
        self.text(label, *rect.center, 22, WHITE if active else "#4e655b", center=True)

    def earth(self, center, radius, happy=True):
        x, y = center
        pygame.draw.circle(self.screen, "#4298cd", center, radius)
        land = [(x-radius//2, y-radius//2), (x-radius//8, y-radius*3//4),
                (x+radius//4, y-radius//4), (x-radius//8, y+radius//5),
                (x-radius//2, y+radius//4)]
        pygame.draw.polygon(self.screen, "#75cf88", land)
        pygame.draw.circle(self.screen, "#75cf88", (x+radius//2, y+radius//4), radius//4)
        for side in (-1, 1):
            pygame.draw.circle(self.screen, INK, (x+side*radius//4, y-radius//9), max(2, radius//15))
        spread = radius//4
        middle = y + radius//5 + (radius//9 if happy else -radius//9)
        pygame.draw.lines(self.screen, INK, False,
                          [(x-spread, y+radius//5), (x, middle), (x+spread, y+radius//5)], 3)

    def heart(self, x, y, active):
        color = "#d94e56" if active else "#d8e1da"
        pygame.draw.circle(self.screen, color, (x-5, y), 6)
        pygame.draw.circle(self.screen, color, (x+5, y), 6)
        pygame.draw.polygon(self.screen, color, [(x-11, y+1), (x+11, y+1), (x, y+12)])

    def draw_menu(self):
        self.earth((500, 94), 52)
        self.text("地球媽媽拯救大作戰", 500, 181, 54, center=True)
        self.text("香港垃圾分類與計算思維遊戲", 500, 226, 26, center=True)
        titles = ("膠樽入門", "分類練習", "傳送帶挑戰", "除錯大挑戰")
        for number, title in enumerate(titles):
            locked = number > self.unlocked
            suffix = "（未解鎖）" if locked else ""
            self.button(self.menu_rect(number), f"第 {number} 關　{title}{suffix}", not locked)
        self.text("小四至小五　｜　選擇已解鎖的關卡開始", 500, 555, 22, center=True)
        self.text("滑鼠拖動物品或積木　·　Esc 返回選關　·　R 重玩", 500, 603, 19, center=True)

    def draw_header(self):
        self.button(self.back, "選關")
        title = "除錯大挑戰" if self.level == 3 else LEVELS[self.level][0]
        self.text(f"第 {self.level} 關　{title}", 500, 45, 32, center=True)
        self.rect(pygame.Rect(28, 83, 944, 78), WHITE)
        self.earth((72, 122), 29, self.emotion == "happy")
        self.text("生命值", 113, 111)
        for index in range(3):
            self.heart(200 + index * 33, 120, index < self.hp)
        if self.level == 1:
            self.text(f"已分類 {self.correct}／5", 500, 123, 22, center=True)
        elif self.level == 2:
            combo_color = "#ac471c" if self.combo >= 3 and int(self.flash * 10) % 2 else INK
            self.text(f"連擊 ×{self.combo}", 500, 123, 26, combo_color, center=True)
        self.text(f"分數 {self.score}", 842, 123, 26, center=True)
        self.text(self.message, 500, 190, 22, center=True)

    def draw_bins(self):
        for key, area in self.bins.items():
            name, symbol, color = BINS[key]
            ink = INK if key == "plastic" else WHITE
            self.rect(area, color)
            pygame.draw.line(self.screen, ink, (area.left+18, area.top+16),
                             (area.right-18, area.top+16), 2)
            self.text(symbol, area.centerx, area.top+48, 32, ink, center=True)
            self.text(name, area.centerx, area.top+88, 22, ink, center=True)

    def draw_sort(self):
        goal = "放對 1 件" if self.level == 0 else "放對 5 件" if self.level == 1 else "取得 150 分，並保留至少 1 點生命值"
        self.text(f"目標：{goal}", 500, 235, 19, center=True)
        self.rect(pygame.Rect(0, 308, WIDTH, 74), "#3d5d58", 0)
        offset = int(self.item_x) % 58
        for x in range(-58 + offset, WIDTH, 58):
            pygame.draw.line(self.screen, "#69847d", (x, 319), (x, 369), 3)
        self.draw_bins()
        if self.level == 0:
            pygame.draw.polygon(self.screen, "#d28b12", [(715, 438), (745, 438), (730, 469)])
        if not self.outcome:
            name = self.sequence[self.item_index]
            self.rect(self.item, WHITE)
            self.rect(self.item, "#75b68f", width=3)
            self.text(name, *self.item.center, 22, center=True)

    def draw_debug(self):
        if self.stage == "repair":
            # 上一行是條件，下一行的彩色區域是可被替換的指令。
            self.text("如果物品是膠樽，就執行：", 500, 219, 19, center=True)
            self.rect(self.slot, "#ffe0dc")
            outline = "#b3473d" if pygame.time.get_ticks() // 350 % 2 else "#d68f88"
            self.rect(self.slot, outline, width=3)
            self.text(f"放入：{BINS[self.rules['plastic']][0]}桶",
                      *self.slot.center, 22, center=True)
            self.text("可用的積木", 500, 329, 19, center=True)
            for key, rect in self.options.items():
                self.button(rect, f"放入：{BINS[key][0]}")
            self.text("試想：如果條件正確，哪一部分指令需要改？", 500, 478, 22, center=True)
            if self.block:
                card = pygame.Rect(0, 0, 198, 60)
                card.center = pygame.mouse.get_pos()
                self.button(card, f"放入：{BINS[self.block][0]}")
        else:
            self.draw_bins()
            if not self.outcome:
                self.text(f"驗證 {self.test_index + 1}／{len(TESTS)}", 500, 245, 26, center=True)
                self.rect(pygame.Rect(345, 282, 310, 82), WHITE)
                self.text(TESTS[self.test_index], 500, 323, 32, center=True)
                self.text("點擊一個桶，預測程式的輸出。", 500, 414, 22, center=True)

    def draw_result(self):
        shade = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
        shade.fill((20, 40, 35, 115))
        self.screen.blit(shade, (0, 0))
        self.rect(pygame.Rect(218, 202, 564, 265), WHITE)
        won = self.outcome == "win"
        title = "地球媽媽得救了！" if won and self.level == 3 else "過關了！" if won else "地球媽媽需要你再試一次"
        self.text(title, 500, 257, 32, center=True)
        detail = ("三個測試全部通過，錯誤規則已修好。" if won and self.level == 3 else
                  f"得分：{self.score}" if won else
                  f"本次得分：{self.score}　｜　試試改變你的分類策略。")
        self.text(detail, 500, 324, 22, center=True)
        self.button(self.retry, "重玩本關")
        self.button(self.next, "下一關" if won and self.level < 3 else "返回選關")

    def draw(self):
        self.screen.fill(BG)
        if self.view == "menu":
            self.draw_menu()
        else:
            self.draw_header()
            if self.level == 3:
                self.draw_debug()
            else:
                self.draw_sort()
            self.text("Esc 返回選關　·　R 重玩本關", 500, 631, 19, center=True)
            if self.outcome:
                self.draw_result()
        self.button(self.mute, "開啟聲音" if self.muted else "靜音")
        pygame.display.flip()

    def run(self):
        while self.running:
            seconds = min(self.clock.tick(60) / 1000, 0.05)
            for event in pygame.event.get():
                self.handle(event)
            if self.running:
                self.update(seconds)
                self.draw()


if __name__ == "__main__":
    try:
        Game().run()
    finally:
        pygame.quit()
